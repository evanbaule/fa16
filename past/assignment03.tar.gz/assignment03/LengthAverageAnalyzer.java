package assignment03;
import java.util.ArrayList;

public class LengthAverageAnalyzer{
	private ArrayList<String> namesA;

	public LengthAverageAnalyzer(ArrayList<String> namesA){
		this.namesA = namesA;
	}

	public String toString() {
		String[] names = {};
		names = namesA.toArray(names); // "list" is the ArrayList field
		return "" + NameUtilities.averageLength(names); // 
	}
}