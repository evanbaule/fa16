package assignment03;

public class NameUtilities{
	public static int countFirstCharacters(char ch, String[] names){
		int ctr = 0;
		if(names==null || names.length < 1){
			ctr = -1;
		}
		else{
			for(String n: names){
				String name = n.toLowerCase();
				
				if(name.charAt(0) == ch){
					ctr++;
				}
			}
		}
		return ctr;
	}


	public static double averageLength(String[] names){
		double avg = 0.0;
		double sum = 0.0;

		if(names == null || names.length < 1){
			avg = -1;
		}
		else {
			for(String n: names){
				if(n != null && n.length() > 0){
					sum += n.length();
				}
			}
		}

		avg = sum/names.length;
		return avg;

	}

	public static int countSyllables(String text) {
		int count = 0;
		int end = text.length() - 1;
		if (end < 0) { 
			return 0; 
		} // The empty string has no syllables

		// An e at the end of the word doesn't count as a vowel
		char ch = text.charAt(end);
		if (ch == 'e' || ch == 'E') {
			end--; 
		}

		boolean insideVowelGroup = false;
		for (int i = 0; i <= end; i++) {
			ch = text.charAt(i);
			String vowels = "aeiouyAEIOUY";
			if (vowels.indexOf(ch) >= 0) {
				// ch is a vowel
				if (!insideVowelGroup) {
					// Start of new vowel group
					count++; 
					insideVowelGroup = true;
				}
			} else {
				insideVowelGroup = false;
			}
		}

		// Every word has at least one syllable
		if (count == 0) {
			count = 1;
		}

		return count;      
	}
	public static double averageNumberOfSyllables(String[] names){
		
		double sum = 0.0;
		double avgS = 0;
		if(names == null || names.length < 1)
			avgS = -1.0;
		else{
			for(String n: names){
				if(n != null && n.length() > 0){
					sum += countSyllables(n);
				}
			}
		}

		avgS = sum/names.length;
		return avgS;
	}
}