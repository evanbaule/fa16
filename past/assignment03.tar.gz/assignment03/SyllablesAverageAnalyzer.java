package assignment03;
import java.util.ArrayList;

public class SyllablesAverageAnalyzer{
	private ArrayList<String> namesA;

	public SyllablesAverageAnalyzer(ArrayList<String> namesA){
		this.namesA = namesA;
	}

	public String toString() {
		String[] names = {};
		names = namesA.toArray(names); // "list" is the ArrayList field
		return "" + NameUtilities.averageNumberOfSyllables(names); // 
	}
}