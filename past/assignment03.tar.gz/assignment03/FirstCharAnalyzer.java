package assignment03;
import java.util.ArrayList;

public class FirstCharAnalyzer{
	private char ch;
	private ArrayList<String> namesA;

	public FirstCharAnalyzer(char ch, ArrayList<String> namesA){
		this.ch = ch;
		this.namesA = namesA;
	}
	public String toString() {
		String[] names = {};
		names = namesA.toArray(names); // "list" is the ArrayList field
		return "" + NameUtilities.countFirstCharacters(ch, names); // ch is the char field
	}
}