package lab10;

public class Student implements Comparable<Person>{
	private Person person;
	private int GPA;
	public Student(Person person, int gPA) {
		super();
		this.person = person;
		GPA = gPA;
	}
	
	@Override
	public String toString(){
		String s;
		s = person.toString() + " " + "(" + GPA + ")";
		return s;
	}

	@Override
	public int compareTo(Person o) {
	     return this.compareTo(o);
	}
	
	public static int compareByGPA(Student a, Student b) {
	    return a.GPA - b.GPA;
	}
	
	public static int compareByNameLength(Student a, Student b){
		int n = b.person.nLen() - a.person.nLen();
		return n;
	}
}
