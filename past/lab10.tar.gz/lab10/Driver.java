package lab10;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Driver {
	
	public static <T> void sortCopyBy(List<T> list, Comparator<? super T> comp) {
	    List<T> copy = new ArrayList<>(list);
	    System.out.println(copy);
	    Collections.sort(copy, comp);
	    System.out.println(copy);
	}
	
	public static <T extends Comparable<T>> void sortCopy(List<T> list){
		List<T> copy = (List<T>) list;
		System.out.println(copy);
		Collections.sort(copy);
		System.out.println(copy);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person p1 = new Person("Evan", "Baule");
		Person p2 = new Person("Gerhard", "Baule");
		
		Person p3 = new Person("Ayman", "Hussein");
		Person p4 = new Person("Naim", "Hussein");
		
		Person p5 = new Person("Omar", "Attia");
		Person p6 = new Person("Bilal", "Attia");
		
		List<Person> people = new ArrayList<>();
		
		people.add(p4);
		people.add(p5);
		people.add(p6);
		
		people.add(p1);
		people.add(p2);
		people.add(p3);
		
		
		sortCopy(people);
		
		Student s1 = new Student(p1, 2);
		Student s2 = new Student(p2, 1);
		Student s3 = new Student(p3, 3);
	
		Student s4 = new Student(p4, 4);
		Student s5 = new Student(p5, 3);
		Student s6 = new Student(p6, 2);
		
		List<Student> students = new ArrayList<>();
		
		students.add(s1);
		students.add(s2);
		students.add(s3);
		
		students.add(s4);
		students.add(s5);
		students.add(s6);
		
		System.out.println("----------------------------------");
		System.out.println("----------------------------------");

		
		sortCopy(students);
		
		Comparator<Student> byStudents = Student::compareByGPA;
		sortCopyBy(students, byStudents);
		
	}
	

}
