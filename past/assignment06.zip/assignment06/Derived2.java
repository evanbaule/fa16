package assignment06;

public class Derived2 extends BaseClass {
	private String field2;

	public Derived2(String field0, String field2) {
		super(field0);
		this.field2 = field2;
	}
	
	@Override
	public String toString(){
		return super.toString() + " " + field2;
	}
	
}
