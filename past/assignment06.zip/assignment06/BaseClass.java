package assignment06;

public class BaseClass {
	private String field0;
	
	public BaseClass(String field0) {
		super();
		this.field0 = field0;
	}

	public String toString(){
		return field0;
	}
	
}
