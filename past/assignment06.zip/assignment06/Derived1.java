package assignment06;

public class Derived1 extends BaseClass {
	private String field1;

	public Derived1(String field0, String field1) {
		super(field0);
		this.field1 = field1;
	}
	
	@Override
	public String toString(){
		return super.toString() + " " + field1;
	}
}
