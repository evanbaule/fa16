package assignment06;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Student {
	private static int nextID = 10001;
	private String name;
	private int id;
	private Set<Course> schedule;
	private String major;
	
	private ArrayList<Course> allCourses = new ArrayList<>();
	
	public ArrayList<Course> getAllCourses() {
		return allCourses;
	}

	public void setAllCourses(ArrayList<Course> allCourses) {
		this.allCourses = allCourses;
	}

	public Student(String major) {
		super();
		this.major = major;
		id = nextID++;
		schedule = new HashSet<>();
		name = Question1.name(id);
	}

	protected Set<Course> getSchedule() {
		return schedule;
	}
	
	public boolean isUnderGrad(){
		return false;
	}
	
	public boolean isGrad(){
		return false;
	}
	
	public void addCourse(Course c){
		schedule.add(c);
	}
	
	public void adjustSchedule(){
		//EMPTY
	}
	
	public boolean hasCourse(int crn){
		boolean ret = false;
		for(int i = 0; i < schedule.size(); i++){
			if(schedule.contains(crn)){
				ret = true;
				return ret;
			}
		}
		return ret;
	}

}
