package assignment06;

public class Question1 {
	public static String name(int n) {
	      if (n >= 26*26*26*26*26*26) return "ZZZZZZ";
	      if (n < 0) return "AAAAAA";
	      char[] chs = Integer.toString(n, 26).toCharArray();
	      char[] chs2 = new char[6];
	      System.arraycopy(chs, 0, chs2, 6-chs.length, chs.length);
	      for(int i = 0; i < 6; i++) {
	         if(chs2[i] == 0) chs2[i] = 'A';
	         if(chs2[i] >= '0' && chs2[i] <= '9') chs2[i] = (char)('A' + chs2[i]-'0');
	         if(chs2[i] >= 'a' && chs2[i] <= 'p') chs2[i] = (char)('A' + 10 + chs2[i]-'a');
	      }		
	      return new String(chs2);
	   }
	   public static void main(String[] args) {
	      for(int n = 10000; n < 11000; n++) {
	         System.out.println(name(n));
	      }
	      System.out.println(name(0));
	      System.out.println(name(26*26*26*26*26*26 - 2));
	      System.out.println(name(26*26*26*26*26*26 - 1));
	      System.out.println(26*26*26*26*26*26); //308,915,776
	   }
	   
	   /*
	   public static int nameToInt(String str){
		   
	   }
	   
	   
	   public static String next(String str){
		   int c;
		   String retStr = null;
		   if(nameToInt(str) != -1){
			   c = (nameToInt(str) + 1);
			   retStr = name(c);
		   }
		   
		   return retStr;
		   
	   }
	   
	   public static String previous(String str){
		   int c;
		   String retStr = null;
		   if(nameToInt(str) != -1){
			   c = (nameToInt(str) - 1);
			   retStr = name(c);
		   }
		   
		   return retStr;
	   }
	   */
	   
}
