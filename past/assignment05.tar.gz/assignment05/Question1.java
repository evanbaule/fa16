package assignment05;

import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

public class Question1 {
	/**
	 * Counts amount of times a character appears within s
	 * @param s is the string that will be analyzed
	 * @return array of integers indexed in alphabetical order
	 */
	public static int[] counter(String s){
		int[] retArr = new int[26];
		
		// null || empty || invalid check for s
		if((s == null) || (s.length() <= 0)){
			throw new IllegalArgumentException("ctr requires input of a non-null, non-empty String");
		}
		else{
			s = s.toLowerCase();
			for(int i = 0; i < 26; i++){
				for(int j = 0; j < s.length(); j++){
					for(char c = 'a'; c <= 'z'; c++){
						if(s.charAt(j) == c){
							retArr[i]++;
						}
					}
				}
			}
		}
		return retArr;
	}
	
	
	/**
	 * Counts amount of times char c appears within String s
	 * @param c is the char to be checked against s
	 * @param s the string to be analyzed
	 * @return an integer value for number of times the char appears
	 */
	public static int count(char c, String s){
		int retVal = 0;
		
		if(s == null || s.length() <= 0){
			throw new IllegalArgumentException("ct requires input of a non-null, non-empty String and a non-null, valid char c");
		}
		else if(c >= 'a' && c <= 'z'){
			for(char ch : s.toCharArray()){
				if(ch == c){
					retVal++;
				}
			}
		}
		return retVal;
	}
	
	static class MyChCounter {
	    char c;
	    int count = 1;
	    MyChCounter(char c1) {
	        c = c1;
	    }
	    void increment() {
	        count++;
	    }
	    @Override
	    public boolean equals(Object obj) {
	        boolean retVal = false;
	        if(obj != null && getClass() == obj.getClass()) {
	            MyChCounter m = (MyChCounter)obj;
	            retVal = (c == m.c && count == m.count);
	        }
	        return retVal;
	    }        
	    @Override
	    public int hashCode() {
	        return Character.hashCode(c)*31 + Integer.hashCode(count);
	    }
	}
	
	/**
	 * Checks if s2 is a permutation of s1
	 * @param s1 string that s2 will be compared to
	 * @param s2 will be compared to s1 to determine if permutation 
	 * @return boolean t/f: t if permutation; f if not
	 */
	public static boolean permutation1(String s1, String s2) {
		if((s1 == null) || (s2 == null) || (s1.length() <= 0) || (s2.length() <= 0)){
			throw new IllegalArgumentException("perm2 requires a 2 non-null, non-empty Strings");
		}
	    return Arrays.equals(counter(s1), counter(s2));
	    
	}
	/**
	 * Checks if s2 is a permutation of s1
	 * @param s1 string that s2 will be compared to
	 * @param s2 will be compared to s1 to determine if permutation 
	 * @return boolean t/f: t if permutation; f if not
	 */
	public static boolean permutation2(String s1, String s2){
		if((s1 == null) || (s2 == null) || (s1.length() <= 0) || (s2.length() <= 0)){
			throw new IllegalArgumentException("perm2 requires a 2 non-null, non-empty Strings");
		}
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();
		boolean retV = true;
		for(char c = 'a'; c <= 'z'; c++){
			if(count(c, s1) != count(c, s2)){
				retV = false;
				break;
			}
		}
		
		return retV;
	}
	
	public static boolean permutation3(String s1, String s2){
		s1 = s1.toLowerCase();
		s2 = s2.toLowerCase();
		Map<Character, MyChCounter> counter1 = new TreeMap<>();
		Map<Character, MyChCounter> counter2 = new TreeMap<>();
		for(char c : s1.toCharArray()){
			if(Character.isLetter(c)){
				if(counter1.containsKey(c)){
					counter1.get(c).increment();
				}
				else{
					counter1.put(c, new MyChCounter(c));
				}
			}
		}
		for(char d : s2.toCharArray()){
			if(Character.isLetter(d)){
				if(counter2.containsKey(d)){
					counter2.get(d).increment();
				}
				else{
					counter2.put(d, new MyChCounter(d));
				}
			}
		}
		
		return counter1.equals(counter2);
	}
	
	public static void main(String[] args){
		System.out.println("--PERMUTATION 1--"); 
		System.out.println(permutation1("Here's the cinema", "The Iceman's here")); //EXPECRT TRUE
		System.out.println(permutation1("Here's the machine", "The Iceman's here")); //EXPECT FALSE
		
		System.out.println("--PERMUTATION 2--");
		System.out.println(permutation2("Here's the cinema", "The Iceman's here")); //EXPECT TRUE
		System.out.println(permutation2("Here's the machine", "The Iceman's here")); //EXPECT FALSE
		
		System.out.println("--PERMUTATION 3--");
		System.out.println(permutation3("Here's the cinema", "The Iceman's here")); //EXPECT TRUE
		System.out.println(permutation3("Here's the machine", "The Iceman's here")); //EXPECT FALSE

		
		
	}
}
