package assignment06;

public class LevelThree extends LevelFour {
	private BankAccount[] bankAccounts;
	public LevelThree(double[] balances){
		super(balances == null ? 0 : balances.length);
		BankAccount[] newArr = new BankAccount[balances.length];
		for(int i = 0; i < balances.length; i++){
			newArr[i] = new BankAccount(balances[i]);
		}
		
		for(int j = 0; j < newArr.length; j++){
			bankAccounts[j] = newArr[j];
		}
	}
	
	@Override
	public double measure(){
		double sum = 0;
		for(BankAccount b: bankAccounts){
			sum += b.getBalance();
		}
		return sum;
	}
	
	public double distance(int i, double mean){
		double retVal;
		double r = (bankAccounts[i].getBalance() - mean);
		retVal = Math.abs(r);
		
		return retVal;
	}

	public BankAccount[] getBankAccounts() {
		return bankAccounts;
	}

	public void setBankAccounts(BankAccount[] bankAccounts) {
		this.bankAccounts = bankAccounts;
	}
	
	public int getLen(){
		return bankAccounts.length;
	}
	
	
}
