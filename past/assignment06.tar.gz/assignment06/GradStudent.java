package assignment06;

public class GradStudent extends Student {
	private String undergradMajor;
	public GradStudent(String major) {
		super(major);
		undergradMajor = major;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void adjustSchedule(){
		//TODO: adjustSchedule uGrad
	}

}
