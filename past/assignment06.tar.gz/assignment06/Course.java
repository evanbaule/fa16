package assignment06;

import java.util.HashSet;
import java.util.Set;

public class Course {
	private static int nextCRN = 10001;
	private String title;
	private int crn;
	private Set<Student> enrollment;
	
	public Course(String title) {
		super();
		this.title = title;
		crn = nextCRN++;
		enrollment = new HashSet<>();
	}
	
	public boolean isUnderGrad(){
		throw new UnsupportedOperationException("No information about level of the course");
	}
	
	public boolean isGrad(){
		throw new UnsupportedOperationException("No information about level of the course");
	}
	
	public int getCrn(){
		return crn;
	}
	
	public void tallyEnrollment(Student[] allStudents){
		for(int i = 0; i < allStudents.length; i++){
			if(allStudents[i].hasCourse(crn)){
				enrollment.add(allStudents[i]);
			}
		}
	}
	
	public int getEnrollmentSize(){
		return enrollment.size();
	}
}
