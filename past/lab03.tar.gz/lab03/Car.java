package lab03;

public class Car{
	private int mileage;
	private String model;

	public Car(int mileage, String model){
		this.mileage = mileage;
		this.model = model;
	}

	//Return mileage
	public int getMileage(){
		return mileage;
	}

	//Return model
	public String getModel(){
		return model;
	}

	//Decide whether or not to sell
	public boolean shouldSell(){
		boolean flag = false;
		if(mileage > 100000){
			flag = true;
		}
		return flag;
	}


	//Main
	public static void main(String[] args){
		Car[] cars = new Car[4];
		cars[0] = new Car(140000, "Infinit M35x");
		cars[1] = new Car(125000, "Mitsubishi 4G Eclipse");
		cars[2] = new Car(46500, "Mazda 6");
		cars[3] = new Car(22000, "Nissan Rogue");

		int carsToSell = 0;
		for(int i = 0; i < cars.length; i++){
			if(cars[i].shouldSell()){
				carsToSell++;
			}
		}

		System.out.println("The for loop returns val: " + carsToSell + " for value carsToSell");
		System.out.println("The expected output of the for loop is: 2.");
	}

}