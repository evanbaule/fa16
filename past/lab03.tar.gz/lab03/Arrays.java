package lab03;

public class Arrays{
	/**
	* Computes the average of the elements of the array
	* @param the array whose elements are to be averaged
	* @return the average of the elements in the array, or -1 if the array is null or empty
	*/
	public static double average(int[] array) {
	    int sum = 0;
	    int ctr = 0;
	    double avg = 0.0;

	    if(array != null && array.length > 0){
	    	for(int i: array){
	    		sum += i;
	    		ctr++;
	    	}
	    	
	    }
	    else{
	    	return -1;
	    }

	    if(ctr!=0){
	    	avg = (sum / ctr);
	    }

	    return avg;
	}

	/**
	* Computes the average of the elements of the array within the given range
	* @param array the array whose elements to average
	* @param lowerBound the index of the first element to include in the computation
	* @param upperBound one more than the index of the last element to include in the computation
	* @return the average of the elements in array from indices lowerBound to
	*         upperBound, excluding the upperBound, or
	*         -1 if the array is null, empty, or lowerBound >= upperBound
	*/
	public static double averageOfRange(int[] array, int lowerBound, int upperBound) {
		int sum = 0;
		int ctr = 0;
		double avg = 0.0;

		if(array != null && array.length > 0){
			for(int i = lowerBound; i < upperBound; i++){
				sum += array[i];
				ctr++;
			}

		}
		else{
			return -1;
		}

		if(ctr!=0){
	    	avg = (sum / ctr);
	    }

		return avg;
	}

	//Main
	public static void main(String[] args){
		int[] nullArray = null;
		int[] emptyArray = new int[0];
		int[] oddArray = {1,3,5,7,9};
		int[] evenArray = {2,4,6,8};

		//nullArray test
		System.out.println(average(nullArray) + "  nullArray average expected: -1");
		
		System.out.println(averageOfRange(nullArray, 1, 4) + "  nullArray averageOfRange expected: -1");

		//emptyArray test
		System.out.println(average(emptyArray) + "  emptyArray average expected: xPLACEHOLDER");
		
		System.out.println(averageOfRange(emptyArray, 1, 4) + "  emptyArray averageOfRange expected: xPLACEHOLDER");

		//oddArray test
		System.out.println(average(oddArray) + "  evenArray average expected: xPLACEHOLDER");
		
		System.out.println(averageOfRange(oddArray, 1, 4) + "  evenArray averageOfRange expected: xPLACEHOLDER");

		//evenArray test
		System.out.println(average(evenArray) + "  oddArray average expected: xPLACEHOLDER");
		
		System.out.println(averageOfRange(evenArray, 1, 3) + "  oddArray averageOfRange expected: xPLACEHOLDER");
		//Corner Cases
		System.out.println("---------------Below this line are corner case tests---------------");

		//0-length
		System.out.println("0 - length:  " + averageOfRange(oddArray, 0, oddArray.length));

		//1-(length-2)
		System.out.println("1 - length-2:  " + averageOfRange(oddArray, 1, oddArray.length-2));

		//2-2 : first = last
		System.out.println("2 - 2:  " + averageOfRange(oddArray, 2, 2));

		//3-1 : first > last
		System.out.println("3 - 1:  " + averageOfRange(oddArray, 3, 1));

		//TryCatch
		try{
			System.out.println("-12, 4:  " + averageOfRange(evenArray, -12, 4));
			System.out.println("0, 241:  " + averageOfRange(oddArray, 0, 241));
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("Out of bounds, ArrayIndexOutOfBoundsException detected");
			System.out.println("------------STACKTRACE ERROR BELOW------------");
			e.printStackTrace();
		}
	}
}