package assignment07;

public enum CSGened {
	A, B, C, F1, G, H, J, L, M, N, O, P, S, Y
}
