package assignment07;
interface Play {
	int takeTurn(int currentState);
}