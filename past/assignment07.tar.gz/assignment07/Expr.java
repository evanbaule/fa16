package assignment07;

public abstract class Expr{
	private Expr left;
	private Expr right;
	
	public Expr getLeft() {
		return left;
	}

	public void setLeft(Expr left) {
		this.left = left;
	}

	public Expr getRight() {
		return right;
	}

	public void setRight(Expr right) {
		this.right = right;
	}

	abstract int eval();

}
