package assignment01;

public class Company{
	private String name;
	private String city;

	/*
	Constructor
	*/
	public Company(String sName, String sCity){
		name = sName;
		city = sCity;
	}

	/*
	name getter/setter
	*/
	public String getName(){
		return name;
	}

	public void setName(String newName){
		name = newName;
	}

	/*
	city getter/setter
	*/
	public String getCity(){
		return city;
	}

	public void setCity(String newCity){
		city = newCity;
	}
}