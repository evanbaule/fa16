package assignment01;

public class HighSchoolStudent{
	private HighSchool highSchool;
	private Person student;

	/*
	Constructor
	*/
	public HighSchoolStudent(HighSchool sHighSchool, Person sPerson){
		highSchool = sHighSchool;
		student = sPerson;
		student.getHistory()[0] = this;
	}

	/*
	highSchool getter/setter
	*/
	public HighSchool getHighSchool(){
		return highSchool;
	}

	public void setHighSchool(HighSchool newSchool){
		highSchool = newSchool;
	}

	/*
	Send student off to a university
	*/
	public UniversityStudent goToUniversity(University univ, Person st){
		UniversityStudent freshman = new UniversityStudent(univ, st);
		return freshman;

	}
}