package assignment08;

import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedListTest {

	private IntLinkedList lle = new IntLinkedList();

	@Test
	public void emptyList() {
		IntLinkedList ll = new IntLinkedList();
		assertEquals("[]", ll.toString());
	}

	@Test
	public void testAdd() {
		IntLinkedList ll = new IntLinkedList();
		ll.startList(1);
		assertEquals("[1]", ll.toString());
	}

	@Test
	public void removeHead() {
		IntLinkedList ll = new IntLinkedList();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(1);
		assertEquals("[3, 5]", ll.toString());
	}

	@Test
	public void removeMid() {
		IntLinkedList ll = new IntLinkedList();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(3);
		assertEquals("[1, 5]", ll.toString());
	}

	@Test
	public void removeLast() {
		IntLinkedList ll = new IntLinkedList();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(5);
		assertEquals("[1, 3]", ll.toString());
	}

}
