package assignment08;

public class IntLinkedList {
	private Node head;
	private Node last;

	public void startList(int i) {
		if (head != null) {
			throw new RuntimeException("List already created");
		} else {
			head = new Node();
			head.i = i;
			last = head;
		}
	}

	public int len() {
		int r = 0;
		if (head != null) {
			Node n = head;
			while (n != null) {
				r++;
				n = n.next;
			}
		}
		return r;
	}

	public void appendList(int i) {
		if (head == null) {
			throw new RuntimeException("Must create list");
		} else {
			last.next = new Node();
			last.next.i = i;
			last = last.next;
		}
	}

	public void remove(int i) {
		if (head == null) {
			throw new RuntimeException("List is empty");
		} else if (head.i == i) {
			head = head.next;
		} else {
			Node temp = head;
			while (temp.next != null) {
				// Find node to remove
				if (temp.next.i == i) {
					// Cut link to the node we want to remove, and since there
					// is no way to access the data the garbage collector gets
					// rid of it

					/*
					 * I used this first but gave me issues with the last node,
					 * reversed logic and it seems to work better? if (temp.next
					 * != null) { temp.next = temp.next.next; } else { last =
					 * temp; }
					 */

					if (temp.next == null) {
						last = temp;
					}
					temp.next = temp.next.next;
				}
				temp = temp.next;
			}
		}
	}

	@Override
	public String toString() {
		if (head == null) {
			return "[]";
		}
		StringBuffer sb = new StringBuffer("[");
		Node temp = head;
		while (true) {
			if (temp == null) {
				sb.append("]");
				return sb.toString();
			} else {
				sb.append(temp.i);
				if (temp.next != null) {
					sb.append(", ");
				}
				temp = temp.next;
			}
		}
	}

	private class Node {
		private int i;
		private Node next;

	}

	public static void main(String[] args) {
		// Creates list of numbers to be worked on
		IntLinkedList primes = new IntLinkedList();
		primes.startList(2);

		// Populates the list of numbers up to specified value for n
		int n = 1001; // Change to increase top bound of list
		for (int i = 3; i < n; i++) {
			primes.appendList(i);
		}

		Node nextPrime = primes.head;
		System.out.print("[");

		// Actual logic for Seive of Eratosthenes
		try {
			while (true) {
				System.out.print(nextPrime.i);
				Node temp = nextPrime;
				while (temp != null && temp.next != null) {
					if (temp.next.i % nextPrime.i == 0) {
						temp.next = temp.next.next;
					}
					temp = temp.next;
				}
				nextPrime = nextPrime.next;
				if (nextPrime.next != null) {
					System.out.print(", ");
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.print("]");
			throw new RuntimeException();
		}

	}
}
