package assignment07;

public class Neg extends Expr {
	private Expr val;

	public Neg(Expr val){
		this.val = val;
	}
	
	@Override
	int eval() {
		if(val.eval() == 0){
			return 1;
		}
		else{
			return 0;
		}
		
	}
	
	
}
