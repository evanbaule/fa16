package assignment07;

import java.util.Random;

public class Smart implements Play {
	
	@Override
	public int takeTurn(int currentState) {
		Random rand = new Random();
		int retVal;
		int r = 2;
		
		while(r < (currentState+1)/2){
			r = r*2;
		}
		
		//Researched bit operations a bit and found this particular approach on stack overflow
		//http://stackoverflow.com/questions/19383248/find-if-a-number-is-a-power-of-two-without-math-function-or-log-function
		
		if(((currentState+1) & currentState) == 0){
			if(currentState == 1){
				r = 1;
				return r;
			}
			r = rand.nextInt(currentState/2)+1;
			return r;
		}
		
		retVal = (currentState - r);
		return retVal;
		
	}

}
