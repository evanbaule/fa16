package assignment07;

public class Num extends Expr{
	private int key;
	public Num(int key){
		this.key=key;
	}
	
	public double getKey(){
		return key;
	}

	@Override
	int eval() {
		return key;
	}
	
}
