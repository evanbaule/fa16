package assignment07;

import assignment06.UndergradCourse;

public class CSGenedCourse extends UndergradCourse{
	CSGened[] geneds;

	public CSGenedCourse(String title, CSGened[] geneds) {
		super(title);
		this.geneds = geneds;
	}

	public CSGened[] getGeneds() {
		return geneds;
	}

	public void setGeneds(CSGened[] geneds) {
		this.geneds = geneds;
	}
	
	

}
