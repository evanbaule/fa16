package assignment04;
import java.util.ArrayList;

public class BankAccount {
	
	private int id;
	private Person customer;
	private static int nextID;

	private double balance;
	public BankAccount(double initialBalance) {
			balance = initialBalance;
			id = ++nextID;
	}
	public void deposit(double amount) {  
		balance += amount;
	}
	public void withdraw(double amount) { 
		balance -= amount;
	}
	public double getBalance() {   
		return balance;
	}

	//changes customer field
	public void setCustomer(Person p){
		customer = p;
	}

	//added getters for new fields
	public int getID(){
		return id;
	}
	public Person getCustomer(){
		return customer;
	}
}