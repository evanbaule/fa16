package assignment04;
import java.util.ArrayList;

public class VariousMethods{
	
	public static int oddEvenCount(long[] arr){
		int ctr = 0;
		if(arr == null){
			ctr = -1;
			return ctr;
		}
		else if(arr.length < 1){
			ctr = 0;
			return ctr;
		}
		else{
			for(int i = 1; i < arr.length ; i += 2){
				if(arr[i] % 2 == 0 && arr[i] != 0){
					ctr++;
				}
			}
		}
		return ctr;
	}
	
	public static int minCount(double min, ArrayList<BankAccount> list){
		int ctr = 0;
		if(list == null || list.size() <= 0){
			ctr = -1;
			return ctr;
		}
		else{
			for(int i = 0; i < list.size(); i++){
				if(list.get(i) != null && list.get(i).getBalance() > min){
					ctr ++;
				}
			}
		}

		return ctr;

	}
	

	public static double justAnExercise(double cap, char initial, BankAccount[] arr){
		double retVal = 0.0;

		if(arr == null || arr.length <= 0){
			retVal = -1;
		}
		else{
			for(int i = 0; i < arr.length; i++){
				if(arr[i] == null){
					retVal = -1;
					return retVal;
				}	
				else{
					String name = arr[i].getCustomer().getName().toLowerCase();
					char init = Character.toLowerCase(initial);
					if((i%3) == 0 && arr[i].getBalance() < cap){
						retVal = arr[i].getBalance();
						return retVal;
					}
					else if((i-1)%3 == 0 && arr[i].getID()%2 == 0){
						retVal = arr[i].getBalance();
						return retVal;
					}
					else if((i-2)%3 == 0 && init == name.charAt(0)){
						retVal = arr[i].getBalance();
						return retVal;
					}
					
				}
			}

		}

		return retVal;
	}

	public static int anotherExercise(ArrayList<BankAccount> list){
		int retVal = 0;
		if(list == null || list.size() <= 0){
			retVal = -1;
			return retVal;
		}
		else{
			int longest = list.get(0).getCustomer().getName().length();
			for(int i = 0; i < list.size(); i++){
				if(list.get(i) != null && list.get(i).getCustomer().getName().length() >= longest){
					retVal = i;
				}
			}
		}
		return retVal;
	}
}






















