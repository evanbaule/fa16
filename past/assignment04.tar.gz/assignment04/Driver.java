package assignment04;
import java.util.ArrayList;

public class Driver{
	public static void main(String[] args){
		long[] array1 = {12, 0 , 3, 4, 13, 12, 22, 93, 41, 26};
		long[] array2 = null;
		long[] array3 = {1};
		long[] array4 = {};

		BankAccount bank1 = new BankAccount(931);
		BankAccount bank2 = null;
		BankAccount bank3 = new BankAccount(-100000000);
		BankAccount bank4 = new BankAccount(1200.3045);
		BankAccount bank5 = new BankAccount(550);
		BankAccount ac1 = new BankAccount(400);
		BankAccount ac2 = new BankAccount(500);
		BankAccount ac3 = new BankAccount(600);

		Person evan = new Person("Evan", 6, 9 , 1969);
		Person brian = new Person("Brian", 22, 2, 1922);
		Person ari = new Person("Ari", 6, 9 , 1969);
		Person abbyM = new Person("Abby", 22, 2, 1922);
		Person ange = new Person("Ange", 6, 9 , 1969);
		Person bari = new Person("Bari", 22, 2, 1922);
		Person abbyU = new Person("Abby", 6, 9 , 1969);
		Person jenna = new Person("Jenna", 22, 2, 1922);

		ac1.setCustomer(abbyM);
		ac2.setCustomer(evan);
		ac3.setCustomer(brian);
		bank1.setCustomer(jenna);
		
		bank3.setCustomer(ari);
		bank4.setCustomer(ange);
		bank5.setCustomer(bari);
		
		System.out.println("b1 id: " + bank1.getID());
		System.out.println("b2 id: " + bank3.getID());
		System.out.println("b3 id: " + bank4.getID());
		System.out.println("ac1 id: " + ac1.getID());
		System.out.println("ac2 id: " + ac2.getID());
		System.out.println("ac3 id: " + ac3.getID());

		System.out.println("-----------");

		ArrayList<BankAccount> bnkArrLst1 = new ArrayList<BankAccount>();
		bnkArrLst1.add(bank1);
		bnkArrLst1.add(bank2);
		bnkArrLst1.add(bank3);
		bnkArrLst1.add(bank4);

		ArrayList<BankAccount> bnkArrLst2 = new ArrayList<BankAccount>();
		bnkArrLst2.add(ac1);
		bnkArrLst2.add(ac2);
		bnkArrLst2.add(ac3);
		bnkArrLst2.add(bank1);

		ArrayList<BankAccount> bnkArrLst3 = new ArrayList<BankAccount>();
		bnkArrLst3.add(bank1);
		bnkArrLst3.add(bank3);
		bnkArrLst3.add(bank4);

		ArrayList<BankAccount> bnkArrLstNull = null;
		ArrayList<BankAccount> bnkArrLstEmpty = new ArrayList<BankAccount>();

		BankAccount[] r1 = null;
		BankAccount[] r2 = {};
		BankAccount[] r3 = {ac2, bank1, ac2, ac2, bank3, bank4};
		BankAccount[] r4 = {bank1, bank3, ac3, bank1, bank1, bank4};
		BankAccount[] r5 = {bank1, bank3, bank4, ac1, ac2};
		BankAccount[] r6 = {bank1, bank3, bank4};
		BankAccount[] r7 = {bank1, bank3, bank4};
		BankAccount[] r8 = {bank1, bank3, bank4};
	
		System.out.println("-------Test oddEvenCount method--------");
		System.out.println("array1: Expect 3, Returns: " + VariousMethods.oddEvenCount(array1));
		System.out.println("array2: Expect -1, Returns: " + VariousMethods.oddEvenCount(array2));
		System.out.println("array3: Expect 0, Returns: " + VariousMethods.oddEvenCount(array3));
		System.out.println("array4: Expect 0, Returns: " + VariousMethods.oddEvenCount(array4));
		
		System.out.println("-------Test minCount method--------");
		System.out.println("List with 4 accounts: Expect 1, Returns: " + VariousMethods.minCount(1000, bnkArrLst1));
		System.out.println("Null list: Expect -1, Returns: " + VariousMethods.minCount(1000, bnkArrLstNull));
		System.out.println("Empty List: Expect -1, Returns: " + VariousMethods.minCount(1000, bnkArrLstEmpty));
		
		System.out.println("-------Tests for justAnExercise method--------");
		System.out.println("Expect: -1, Return: " + VariousMethods.justAnExercise(100, 'e', r1));
		System.out.println("Expect: -1, Return: " + VariousMethods.justAnExercise(100, 'e', r2));
		System.out.println("Expect: 500, Return: " + VariousMethods.justAnExercise(100, 'e', r3));
		System.out.println("Expect: 600, Return: " + VariousMethods.justAnExercise(100, 'e', r4));
		System.out.println("Expect: 500, Return: " + VariousMethods.justAnExercise(100, 'e', r5));
		
		
		System.out.println("----- anotherExercise Test -----");
		System.out.println("Expect: 0, Return: " + VariousMethods.anotherExercise(bnkArrLst3));
		System.out.println("Expect: 3, Return: " + VariousMethods.anotherExercise(bnkArrLst2));
		
		

	}
}