package lab08;

public class Card {
	public static enum Suit { Hearts, Diamonds, Clubs, Spades };
	
	private Suit suit;
	private int value;
	
	public Card(Suit suit, int value) {
		super();
		this.suit = suit;
		this.value = value;
	}
	
	public Suit getSuit() {
		return suit;
	}

	public void setSuit(Suit suit) {
		this.suit = suit;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}
	
	@Override
	public boolean equals(Object other){
		boolean retV = true;
		if(!(other instanceof Card)){
			retV = false;
			return retV;
		}
		else{
			Card temp = (Card)other;
			if((this.suit == temp.suit) && (this.value == temp.value)){
				retV = true;
			}
		}
		
		return retV;
	}
	
	@Override 
	public int hashCode(){
		return (31 * suit.hashCode() + 7 * Integer.hashCode(value));
	}
	
	@Override
	public String toString(){
		String ret = "";
		if(this.value == 11){
			ret += "Ace " + "of " + this.suit;
			return ret;
		}
		ret += this.value + " of " + this.suit;
		return ret;
	}
	
	public static void main(String[] args){
		Card sevenOfSpades = new Card(Suit.Spades, 7);
		System.out.println(sevenOfSpades.toString());
		
		Card aceOfHearts = new Card(Suit.Hearts, 11);
		System.out.println(aceOfHearts.toString());
		
		Card threeOfClubs = new Card(Suit.Clubs, 3);
		System.out.println(threeOfClubs.toString());
		
		Card nineOfDiamonds = new Card(Suit.Diamonds, 9);
		System.out.println(nineOfDiamonds.toString());
		
	}
	
}
