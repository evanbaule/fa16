package lab08;

import java.util.ArrayList;

public class BlackjackMethod extends ComputationMethod {

	@Override
	public int compute(ArrayList<Card> cards) {
		int retVal = 0;
		int ctr = 0;
		for(Card c: cards){
			if(c.getValue() + retVal > 21){
				if(c.getValue() == 11){
					ctr++;
				}
				else{
					retVal += c.getValue();
				}
			}
			else if(c.getValue() + retVal <= 21){
				retVal += c.getValue();
			}
		}
		retVal += ctr;
		return retVal;
	}
	
}	
