package lab08;

import static org.junit.Assert.*;

import org.junit.Test;

import lab08.Card.Suit;

public class TestValue {
	Card d1= new Card(Suit.Diamonds, 1);
	Card d2 = new Card(Suit.Diamonds, 2);
	Card d3 = new Card(Suit.Diamonds, 3);
	Card s4 = new Card(Suit.Spades, 4);
	Card s5 = new Card(Suit.Spades, 5);
	Card s6 = new Card(Suit.Spades, 6);
	Card h7 = new Card(Suit.Hearts, 7);
	Card h8 = new Card(Suit.Hearts, 8);
	Card h9 = new Card(Suit.Hearts, 9);
	Card c10 = new Card(Suit.Clubs, 10);
	Card c11 = new Card(Suit.Clubs, 11);
	
	
	@Test
	public void test() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(d2);
		input.addCard(s4);
		
		int t = input.value();
		assertEquals(6, t);
	}
	
	@Test
	public void test2() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(c11);
		input.addCard(c10);
		
		int t = input.value();
		assertEquals(21, t);
	}
	
	@Test
	public void test3() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(c11);
		input.addCard(c11);
		
		int t = input.value();
		assertEquals(12, t);
	}
	
	@Test
	public void test4() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(c11);
		input.addCard(c11);
		input.addCard(c11);
		
		int t = input.value();
		assertEquals(13, t);
	}
	
	@Test
	public void test5() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(c10);
		input.addCard(c10);
		input.addCard(d2);
		
		int t = input.value();
		assertEquals(22, t);
	}
	
	@Test
	public void test6() {
		BlackjackHand input = new BlackjackHand();
		input.addCard(c10);
		input.addCard(c10);
		input.addCard(c11);
		
		int t = input.value();
		assertEquals(21, t);
	}
	
}
