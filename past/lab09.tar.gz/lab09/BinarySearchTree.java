package lab09;

import java.awt.List;

public class BinarySearchTree {
	private Node root;
	
	
	public Node insertHelper(Node cur, int i){
		Node retNode;
		
		
		return retNode;
	}
	
	
	public void insert(int i){
		Node cur = new Node(i);
		if(root == null){
			root = new Node(i);
		}
		else{
			if(root.getKey() < i){
				if(root.getRight() == null){
					root.setRight(cur);
				}
				else{
					root.setRight(insertHelper(cur, i));
				}
			
			}
			if(root.getKey() > i){
				if(root.getLeft() == null){
					root.setLeft(cur);
				}
			
			}
		}
	}
	
	public Integer find(int i){
		Integer retVal;
		Node cur;
		if(root.getKey() == i)
		if(root.getKey() < i){
			cur = root.getRight();
			if(cur.getKey() == i){
				retVal = cur.getKey();
			}
			else{
				cur = cur.getLeft();
				
			}
		}
		if(root.getKey() > i){
			cur = root.getLeft();
			if(cur.getKey() == i){
				retVal = cur.getKey();
			}
			else{
				
			}
		}
		return retVal;
	}
	
	public List<Integer> getElems(){
		List<Integer> retList;
		
		return retList;
	}
	
	
}
