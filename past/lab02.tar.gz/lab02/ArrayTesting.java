package lab02;

public class ArrayTesting{

	public static void main(String[] args) {
		int[] testArray = new int[10];
		printTestArray(testArray);
		sumArray(testArray);
	}

	public static void printTestArray(int[] a){
			for(int i = 0; i < a.length-1; i++) {
			System.out.println("val @ " + i + " is: " + a[i]);
		}	
	}

	public static void sumArray(int[] a){
		
		int sum = 0;
		for(int i:a){
			sum += i;
		}
		System.out.println("The sum of the values in the array is: " + sum);
	}
	
}




