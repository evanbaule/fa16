package lab07;

public class Driver {

	public static void main(String[] args) throws Exception{
		FileBuffer fb = new FileBuffer("pasta.txt");
		ScratchBuffer sb = new ScratchBuffer();
		ShellBuffer shb = new ShellBuffer();
		
		Editor e1 = new Editor(fb);
		Editor e2 = new Editor(sb);
		Editor e3 = new Editor(shb);
		e1.type("jordan is");
		e1.save();
		e1.draw();
		
		e2.save();
		e2.draw();
		e2.type("a fratboy");
		
		e3.type("l o l");
		e3.save();
		e3.draw();
	}

}
