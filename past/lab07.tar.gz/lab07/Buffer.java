package lab07;

import java.util.List;

public class Buffer {
	protected List<String> lines;
	
	public int getNumLines(){
		return lines.size();
	}
	public String getText(){
		return String.join("\n", this.lines);
	}
	
	public void draw(){
		System.out.println(this.getText());
	}
	
	public void save(){
		throw new UnsupportedOperationException();
	}
	
	public void type(String toType){
		if(toType.length() <= 0){
			lines.add(toType);
		}else{
			for(char c: toType.toCharArray()){
				if(c == '\n'){
					lines.add("");
				}else{
					//TODO: Append c to end of last string in lines
				}
			}
		}
	}
}
