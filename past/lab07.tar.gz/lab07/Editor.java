package lab07;

public class Editor {
	private Buffer buff;
	private StatusBar sb;
	
	public Editor(Buffer buff){
		this.buff = buff;
		sb = new StatusBar(buff);
	}
	
	
	public void save() throws Exception{
		buff.save();
	}

	public void type(String toType) {
		buff.type(toType);
	}

	public void draw(){
		buff.draw();
		sb.draw();
	}
}
