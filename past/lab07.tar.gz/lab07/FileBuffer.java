package lab07;

import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;

public class FileBuffer extends Buffer{
	
	private String fileName;
	
	public FileBuffer(String fileName){
		this.fileName = fileName;
		try{
			lines = java.nio.file.Files.readAllLines(Paths.get(fileName));
		}
		catch(IOException e){
			lines = new ArrayList<String>();
		}
	}
	
	@Override
	public void save(){
			try {
				java.nio.file.Files.write(Paths.get(fileName), lines);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
}
