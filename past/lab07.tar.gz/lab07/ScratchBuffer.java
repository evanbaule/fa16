package lab07;

public class ScratchBuffer extends FileBuffer{
	public ScratchBuffer() {
		super("scratch");
	}

}
