package lab06;

import static org.junit.Assert.*;

import org.junit.Test;

public class Tester {	
	@Test
	public void testFactorialZero() {
	    assertEquals(1, Loops.slowFactorial(0));
	}
	
	@Test
	public void testFactorialOne() {
	    assertEquals(1, Loops.slowFactorial(1));
	}
	
	@Test
	public void testFactorialFive() {
	    assertEquals(120, Loops.slowFactorial(5));
	}
	
	@Test(expected=IllegalArgumentException.class)
	public void testFactorialNegative() {
	    Loops.slowFactorial(-1);
	}
	

}
