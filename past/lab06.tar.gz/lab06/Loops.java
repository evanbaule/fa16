package lab06;

public class Loops {

	public static void main(String[] args) {
		star_pattern_v1(3);
		System.out.println("------");
		star_pattern_v2(3);
		
		System.out.println("------");
		System.out.println(slowFactorial(0));
		System.out.println(slowFactorial(1));
		System.out.println(slowFactorial(2));
		System.out.println(slowFactorial(3));
		System.out.println(slowFactorial(4));
		System.out.println(slowFactorial(5));
		System.out.println(slowFactorial(6));
		
	}
	
	public static void star_pattern_v1(int n){
		for(int i = 0; i < n; i++){
			for(int j = 0; j <= i; j++){
				System.out.print('*');
			}
			System.out.println();
		}
		
	}
	
	public static void star_pattern_v2(int n){
		for(int i = n; i >= 0; i--){
			for(int j = 0; j < i; j++){
				System.out.print('*');
			}
			System.out.println();
		}
	}
	
	
	
	/**
	 * Takes n factorial of the input integer given
	 * @param n will take factorial of this integer, handles 0 < n  otherwise throws exception
	 * @return value of factorial to 'n'
	 */
	public static int slowFactorial(int n){
		//TODO change to fit piazza parameters
		int retVal = 1;
		if(n < 0){
			throw new IllegalArgumentException("Cannot take the factorial of a negative number");
		}
		for(int i = 1; i < n; i++){
			retVal += retVal*(i);
		}
		return retVal;
		
	}

}
