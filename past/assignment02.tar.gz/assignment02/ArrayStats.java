package assignment02;

/*
Evan M. Baule
Assignment 02
CS 140


A null array will return 0 for double values = null, return -1 for int values

*/

public class ArrayStats{
	private double[] doubleArray;
	private double avg;
	private double maxElement;
	private double minElement;
	private int minIdx;
	private int maxIdx;

	public ArrayStats(double... vals) {
		double minElement = vals[0];
		int minIdx = -1;
		double maxElement = vals[0];
		int maxIdx = -1;
		double sum = 0;
		if(vals != null && vals.length > 0){
			for(int i = 0; i < vals.length-1; i++){
				if(vals[i] < minElement){
					minElement = vals[i];
					minIdx = i;
				}
				else if(vals[i] > maxElement){
					maxElement = vals[i];
					maxIdx = i;
				}
				else{
					minElement = 0.0;
					maxElement = 0.0;
				}
				sum += vals[i];
			}
			avg = sum/vals.length;
		}
		// in the constructor assign vals as the value of the array field
		// and compute the other 5 fields if vals is not null or empty and
		// do all these 5 computations using one for loop.
	} 

	//Get methods for object fields

	public double[] getData(){
		return doubleArray;
	}

	public double getAvg(){
		return avg;
	}

	public double getMax(){
		return maxElement;
		
	}

	public double getMin(){
		return minElement;
		
	}

	public int getMaxIdx(){
		return maxIdx;
		
	}

	public int getMinIdx(){
		return minIdx;
	}


}