package lab04;
import java.util.ArrayList;

public class Library{
	ArrayList<Book> bookList;

	public Library(){
		bookList = new ArrayList<>();
	}

	public void addBook(Book b){
		if(b != null){
			bookList.add(b);
		}
	}

	public int numBooks(){
		return bookList.size();
	}

	public void printLibrary(){
		System.out.println(bookList);
	}

	public double averageLengthOfBooks(){
		double avg;
		double total = 0;
		if(bookList.size() < 1) {
			avg = -1;
			return avg;
		}
		else {
			for(Book b: bookList){
				total += b.getPages();
			}
			avg = total/bookList.size();
		}
		return avg;

	}

	public Book checkoutBook(int index){
		Book temp = bookList.get(index);
		bookList.remove(index);
		return temp;

	}

	public static void main(String[] args){
		Library myLibrary = new Library();
		Book lotr1 = new Book("The Fellowship of the Ring", 1000);
		Book lotr2 = new Book("The Two Towers", 1100);
		Book lotr3 = new Book("The Return of the King", 1200);

		myLibrary.addBook(lotr1);
		myLibrary.addBook(lotr2);
		myLibrary.addBook(lotr3);

		System.out.println("Contents of Library:");
		myLibrary.printLibrary();
		System.out.println("-------------------");

		System.out.println("Exected output of method averageLengthOfBooks: 1100");
		System.out.println(myLibrary.averageLengthOfBooks());

		myLibrary.checkoutBook(1);
			
		System.out.println("Checked out 'The Two Towers'(Index 1):");
		System.out.println("-------------------");

		System.out.println("Contents of Library:");
		myLibrary.printLibrary();


	}
}