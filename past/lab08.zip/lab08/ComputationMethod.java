package lab08;

import java.awt.List;
import java.util.ArrayList;

public abstract class ComputationMethod {
	public abstract int compute(ArrayList<Card> cards);
}
