package lab04;
import java.util.ArrayList;
public class Book{
	private String name;
	private int pages;

	//Constructor
	public Book(String name, int pages){
		this.name = name;
		if(pages <= 0){
			throw new IllegalArgumentException("Invalid value for 'pages'.");
		}
		else {
			this.pages = pages;
		}
		
	}

	//Return methods
	public String getName(){
		return name;
	}

	public int getPages(){
		return pages;
	}

	//toString
	public String toString(){
		String oString = name + " " + pages;
		return oString;
	}
}