{\rtf1\ansi\ansicpg1252\cocoartf1348\cocoasubrtf170
{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural

\f0\fs24 \cf0 README\
\
Evan M. Baule\
Binghamton University - Watson Computer Science 2016\
\
This code was submitted to be graded by the class instructor and/or teaching assistants.\
Any questions/remarks made within the /*commented out*/ portions of the code are directed \
towards them and should be ignored for any other reason.\
\
This assignment was submitted on September 14th, 2016 and received a score of 9.5/10.\
\
The assignment specification is included in the repository under \'91a2spec.pdf\'92\
\
}