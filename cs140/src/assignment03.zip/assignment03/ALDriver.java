package assignment03;

import java.util.ArrayList;

public class ALDriver{
	public static void main(String[] args){

		// DOLLARS AND CENTS TESTING
		System.out.println("------------------------------------");
		System.out.println("TESTING FOR DOLLARS AND CENTS CLASS");
		System.out.println("I assumed you wanted to see these tests again?");
		System.out.println("------------------------------------");

		DollarsAndCents testAmt1 = new DollarsAndCents(4L);
		DollarsAndCents testAmt2 = new DollarsAndCents(135);
		DollarsAndCents testAmt3 = new DollarsAndCents(9, 91);
		DollarsAndCents testAmt4 = new DollarsAndCents(testAmt1);
		DollarsAndCents testAmt5 = new DollarsAndCents();

		//Test Constructors
		System.out.println("Test testAmt1: " + testAmt1.toString() + ". Expect 4.00");
		System.out.println("Test testAmt2: " + testAmt2.toString() + ". Expect 1.35");
		System.out.println("Test testAmt3: " + testAmt3.toString() + ". Expect 9.91");
		System.out.println("Test testAmt4: " + testAmt4.toString() + ". Expect 4.00");
		System.out.println("Test testAmt5: " + testAmt5.toString() + ". Expect 0");

		//Add tester
		System.out.println("Test adding testAmt1 (" + testAmt1.toString() + "), testAmt2 (" + testAmt2.toString() + "), and testAmt3 (" + testAmt3.toString() + "), to 0.0: " + testAmt5.add(testAmt1, testAmt2, testAmt3));

		//lessThan tester
		System.out.println("Test whether testAmt2 (1.35) is less than testAmt1 (4.00), expect true: " + testAmt2.lessThan(testAmt1));

		//subtract tester
		System.out.println("Test the subraction of testAmt2 (1.35) from testAmt1 (4.00), expect 2.65: " + testAmt1.subtract(testAmt2));

		//testUpOrDown
		System.out.println("Test multiplication of testAmt2 (1.35) by factor 2, expect 2.70: " + testAmt2.upOrDown(2));

		System.out.println("--------------------------------------------");
		System.out.println("TESTING FOR ARRAYLIST NAME RESOURCES METHODS");
		System.out.println("--------------------------------------------");
		ArrayList<String> nameList = new ArrayList<String>();
		for(int i = 0; i < 1001; i++){
			nameList.add(resources.NamesResource.getRandomFirstName());
		}

		FirstCharAnalyzer fCA = new FirstCharAnalyzer('r', nameList);
		LengthAverageAnalyzer lAA = new LengthAverageAnalyzer(nameList);
		SyllablesAverageAnalyzer sAA = new SyllablesAverageAnalyzer(nameList);

		
		ArrayList<Object> test = new ArrayList<Object>();
		test.add(fCA);
		test.add(lAA);
		test.add(sAA);

		System.out.println(test);
	}
}