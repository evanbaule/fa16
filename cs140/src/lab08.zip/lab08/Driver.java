package lab08;

import java.util.ArrayList;
import java.util.Arrays;

import lab08.Card.Suit;

public class Driver {

	public static void main(String[] args) {
		Card d1= new Card(Suit.Diamonds, 1);
		Card d2 = new Card(Suit.Diamonds, 2);
		Card d3 = new Card(Suit.Diamonds, 3);
		Card s4 = new Card(Suit.Spades, 4);
		Card s5 = new Card(Suit.Spades, 5);
		Card s6 = new Card(Suit.Spades, 6);
		Card h7 = new Card(Suit.Hearts, 7);
		Card h8 = new Card(Suit.Hearts, 8);
		Card h9 = new Card(Suit.Hearts, 9);
		Card c10 = new Card(Suit.Clubs, 10);
		Card c11 = new Card(Suit.Clubs, 11);
		
		BlackjackHand b1 = new BlackjackHand();
		b1.addCard(d2);
		b1.addCard(c10);
		b1.addCard(c10);
		
		System.out.println(b1.value());
		
		///
		
		BlackjackMethod b2 = new BlackjackMethod();
		ComposedHand c1 = new ComposedHand(b2);
		c1.addCard(c10);
		c1.addCard(c10);
		c1.addCard(d2);
		
		System.out.println(c1.value());
		
		

	}

}
