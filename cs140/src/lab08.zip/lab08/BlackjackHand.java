package lab08;

public class BlackjackHand extends CardHand {

	@Override
	public int value() {
		int retVal = 0;
		int ctr = 0;
		for(Card c: cards){
			if(c.getValue() + retVal > 21){
				if(c.getValue() == 11){
					ctr++;
				}
				else{
					retVal += c.getValue();
				}
			}
			else if(c.getValue() + retVal <= 21){
				retVal += c.getValue();
			}
		}
		retVal += ctr;
		return retVal;
	}

}
