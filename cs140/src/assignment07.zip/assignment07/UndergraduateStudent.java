package assignment07;

import java.util.HashSet;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Set;


import assignment06.Student;
import assignment06.Course;

public class UndergraduateStudent extends Student{
	
	public UndergraduateStudent(String major) {
		super(major);
	}

	public boolean isUnderGrad(){
		return true;
	}
	
	public boolean satisfiesCSGened(){
		//returns true if the courses in getAllCourses() combine to satisfy all of the requirements
		try (PrintWriter out = new PrintWriter("test.log")) {
			ArrayList<Set<CSGened>> waysToSatisfy = new ArrayList<Set<CSGened>>();
			HashSet<CSGened> hs = new HashSet<CSGened>();
			waysToSatisfy.add(hs);
			
			boolean cSatisfied = false;
			boolean f1Satisfied = false;
			boolean oSatisfied = false;
			
			for(Course crs: getAllCourses()){
				if(crs instanceof CSGenedCourse){
					CSGenedCourse gecrs = (CSGenedCourse)crs;
					out.println(Arrays.toString(gecrs.getGeneds()));
					int sz = waysToSatisfy.size();
					int len = gecrs.getGeneds().length;
					
					if(len > 1){
						for(CSGened c: gecrs.getGeneds()){
							for(int i = 0; i < len-1; i++){
								for(int j = 0; j < sz; j++){
									HashSet<CSGened> copy = new HashSet<CSGened>();
									copy.addAll(waysToSatisfy.get(j));
									waysToSatisfy.add(copy);
									for(Set<CSGened> s : waysToSatisfy) {
										out.println(s);
									}
								}
							}
							for(int i = 0; i < len; i++){
								for(int j = i*sz; j < (i+1)*sz; j++){
									if(gecrs.getGeneds()[i] == CSGened.C){
										cSatisfied = true;
									}
									else if(gecrs.getGeneds()[i] == CSGened.O){
										oSatisfied = true;
									}
									else if(gecrs.getGeneds()[i] == CSGened.J){
										cSatisfied = true;
										oSatisfied = true;
									}
									else if(gecrs.getGeneds()[i] == CSGened.F1){
										f1Satisfied = true;
									}
									else {
										waysToSatisfy.get(j).add(gecrs.getGeneds()[i]);
									}
									
									for(Set<CSGened> s : waysToSatisfy){
										out.println(s);
									}
								}
							}
						}
						
						for(Set s: waysToSatisfy){
							if(s.contains(CSGened.B)){
								s.remove(s);
								s.add(CSGened.S);
								s.add(CSGened.Y);
							}
							out.println(s + " " + cSatisfied + " " + oSatisfied + " " + f1Satisfied);
							
							if(cSatisfied && oSatisfied && f1Satisfied && (s.size() == 9)){
								return true;
							}
						}
						
						
						
					}
				}
				
			}
			
			out.close();
		} 
		catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
		
		return false;
	}
	
}
