package assignment06;

public class LevelOne extends LevelTwo {
	public LevelOne(double[] balances) {
		super(balances);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double measure(){
		double largest = 0;
		for(int i = 0; i < super.getLen(); i++){
			if(super.getBankAccounts()[i].getBalance() > largest){
				largest = super.getBankAccounts()[i].getBalance();
			}
		}
		
		return largest;
	}
}
