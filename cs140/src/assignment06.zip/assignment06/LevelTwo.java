package assignment06;

public class LevelTwo extends LevelThree {
	
	public LevelTwo(double[] balances) {
		super(balances);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double measure(){
		double retVal;
		if(super.getLen() == 0){
			retVal = 0;
		}
		else{
			double x = super.measure();
			double y = super.getLen();
			retVal = (x / y);
		}
		return retVal;
	}
}
