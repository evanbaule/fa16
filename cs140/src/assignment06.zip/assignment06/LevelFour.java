package assignment06;

public class LevelFour {
	private int num;

	public LevelFour(int num) {
		super();
		this.num = num;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}
	
	public double measure(){
		return num;
	}
	
	public double value(){
		return num;
	}
}
