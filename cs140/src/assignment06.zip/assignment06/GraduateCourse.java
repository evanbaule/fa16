package assignment06;

public class GraduateCourse extends Course {

	public GraduateCourse(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}
	
	@Override 
	public boolean isGrad(){
		return true;
	}
	
	@Override
	public boolean isUnderGrad(){
		return false;
	}

}
