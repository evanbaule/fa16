package lab05;

import java.util.ArrayList;

public class Q2 {
    public int multiply(ArrayList<Integer> alist) {
    	int prod = 1;
    	if(alist.size() < 0){
    		prod = 0;
    	}
    	else{
    		for(int i = 0; i < alist.size(); i++){
    			if(alist.get(i)!= 0){
    				prod = prod * alist.get(i);
    			}
    			
    		}
    	}
    	return prod;
        // compute and return the product of all of the non-zero elements
        // inside of `alist`. Assume `alist` is not null but if it is empty
        // return 0.
        // you may assume `alist` is either empty or has at least one non-zero element.
        // hence the return value can only be 0 if the array is empty.
    }
}
