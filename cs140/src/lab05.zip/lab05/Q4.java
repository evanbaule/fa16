package lab05;

public class Q4 {
    public int[] reverse(int[] array) {
    	int[] newArray = new int[array.length];
    	for(int i = 0; i < array.length; i++){
	    	newArray[i] = array[(array.length-1)-i];
	}
    	
    	return newArray;
        // return a new array with
        // the elements of `array` reversed.
        // Assume `array` is not null.
    }
}
