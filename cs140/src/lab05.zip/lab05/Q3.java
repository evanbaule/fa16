package lab05;

public class Q3 {
    public int countMax(int[] array) {
    	int max = 0;
    	int ctr = 0;
    	if(array == null){
    		return max;
    	}
    	else{
    		for(int a: array){
    			if(a > max) max = a;
    		}
    		for(int a: array){
    			if(a == max) ctr++;
    		}
    	}
    	return ctr;
    	
        // First compute the maximum integer inside of `array`.
        // Then, in another loop, calculate the count of how many
        // times that value occurs in the array. Return this count
        // Assume that `array`
        // is not null but return 0 if it is empty.
    }
}
