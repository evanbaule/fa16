package assignment08.model;

import assignment08.view.DynamicScreenManager;

public abstract class BurgerModel {
	private static String language = "English";
	DynamicScreenManager screen = DynamicScreenManager.getHandle();

	public static void setLanguage(String s) {
		language = s;
	}

	public static String getLanguage() {
		return language;
	}

	public abstract int getTotalCalories();

	public abstract Double getTotalCost();
}