package assignment02;
/**
 * Class to manage money in dollars and cents
 *
 * @author CS140
 */
public class DollarsAndCents {
		// we need two private fields: a long called dollars and an int called cents
	private final long dollars;
	private final int cents;

	public DollarsAndCents(long dlrs) {
	// this one is implemented for you check how the exception is thrown
	 	if (dlrs < 0) throw new IllegalArgumentException("argument cannot be negative");
	 	dollars = dlrs;
	 	cents = 0;
	}
	
	 
	public DollarsAndCents(int cts) {
		// this one is done for you. Note that if we called new DollarsAndCents(456),
		// dollars would he 4 and cents would be 56 (cents cannot exceed 99)
		 if (cts < 0) throw new IllegalArgumentException("argument cannot be negative");
		 	dollars = cts/100;
		 	cents = cts%100;
		 }

	 /**
	 * Constructor that initializes both the dollars and the cents field to
	 * the given amounts. The cents are adjusted to be less than one dollar.
	 * @param dlrs The amount of dollars in the new account.
	 * @param cts The amount of the cents in the new account. if the number of
	 * cents exceeds a dollar, the excess dollars are added to the dollars field
	 * and only the cents less than one dollar remain.
	 * @throws IllegalArgumentException if either of the parameters is negative
	 */
	public DollarsAndCents(long dlrs, int cts) {
		// use the ideas from the previous constructors to see how to do this
		if (dlrs < 0 && cts < 0) throw new IllegalArgumentException("argument cannot be negative");
		
		if(cts > 100){
			cts -= 100;
			dlrs += 1;
		}

		cents = cts;
		dollars = dlrs;
	}

	
	public DollarsAndCents(DollarsAndCents dc) {
		// just copy the dollars and cents values from dc. Even though the fields are private
		// you CAN access dc.dollars and dc.cents
		dollars = dc.dollars;
		cents = dc.cents;
	}

		 

	 /**
	 * A no argument constructor that creates an object with both fields zero.
	 */
	public DollarsAndCents() {
		dollars = 0;
		cents = 0;

	 }

	 /**
	 * Return a new object with the dollars and cents that are the sum of
	 * the fields the receiver and all the parameters. If the amount of cents exceeds
	 * one dollar the excess is passed to the dollars field.
	 * @param dcs a list of zero or more DollarsAndCents objects
	 * @return a DollarsAndCents object with the sum of all the dollars and
	 * cents in the receiver and the parameters.
	 */
	public DollarsAndCents add(DollarsAndCents... dcs) {
		long dlrs = this.dollars; 
		int cts = this.cents;
		if(dcs!= null){
			for(DollarsAndCents dc: dcs){
				dlrs += dc.dollars;
				cts += dc.cents;
				
				if(cts >= 100){
					cts = (-1)*(100 - cts);
					dlrs += 1;
				}
			}
		}
		DollarsAndCents addDC = new DollarsAndCents(dlrs, cts);
		return addDC;
		// note you treat dcs as an array
		// the cents in the return value must be less than 100
	}

		//BY THE WAY, the following method suggests we should define an equals method but
		//we will do this when we have a chance to talk about the hashCode method

	 /**
	 * Tests if this object is less than the parameter. Consider the
	 * dollars and cents as money and test if this amount is less than
	 * the parameter's amount
	 * @param dc a DollarsAndCents object to be compared with this object
	 * @return true if this object is less than the other object in
	 * terms of dollars and cents, otherwise false
	 */
	public boolean lessThan(DollarsAndCents dc) {
		if(dollars < dc.dollars){
			return true;
		}
		else if(dollars == dc.dollars){
			if(cents < dc.cents){
				return true;
			}
		}
		return false;
		// if dollars is less than dc.dollars the return value is true
		// if dollars is equal to dc.dollars then if cents is less
		// than dc.cents the return value is true
		// otherwise the return value is false
	}

	 
	public DollarsAndCents subtract(DollarsAndCents dc) {

		if(dollars != dc.dollars || cents != dc.cents){
			if(!dc.lessThan(this)){
				throw new IllegalArgumentException("Cannot return a negative value, invalid input");
			}
			else {
				long dlrs = (dollars - dc.dollars);
				int cts = (cents - dc.cents);

				if(cts < 0){
					dlrs = dlrs -1;
					cts = 100-(-1)*cts;
				}

				return new DollarsAndCents(dlrs, cts);
			}
		}
		else {
			return new DollarsAndCents(0, 0);
		}
	}
		// declare a DollarsAndCents return value initially null ---- dont need to do this
		// if either of dollars and dc.dollars or cents and dc.cents are different then
		// throw an exception if(!dc.lessThan(this)) -- this means dc is not lessThan 
		// this object. Continue by defining local variables dlrs and cts equal to
		// dollars - dc.dollars and cents - dc.cents, respectively
		// adjust dlrs and cts to make cts positive if necessary.
		// the return value is set to a new object with arguments dlrs and cts
		// else is a new object with its fields equal to 0.

	 /**
	 * Returns a new object that based on the receiver's dollars and cents
	 * modifies by a positive factor. 
	 * @param factor the multiplying factor for the new object
	 * @return a new object with fields that are the receiver's fields
	 * modified by the factor
	 * @throws IllegalArgumentException if the factor is zero
	 */
	public DollarsAndCents upOrDown(double factor) {
		long dlrs;
		int cts;
		double temp = (dollars + cents/100.0) * factor;
		dlrs = (long)temp;
		cts = (int)Math.round((temp - (long)temp)*100);
		DollarsAndCents fDC = new DollarsAndCents(dlrs, cts);
		return fDC;

		// This computation must be done with doubles
		// double temp = (d+c/100.0)*factor;
		// the return value with have (long)temp for dollars and
		// (int)Math.round((temp - (long)temp)*100);
	 }

	@Override
	public String toString() {
	 // this is a method overridden from class Object
	 	return "$" + dollars + "." + cents;
	 }
} 