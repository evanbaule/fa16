README

Evan M. Baule
Binghamton University - Watson Computer Science 2016

This code was submitted to be graded by the class instructor and/or teaching assistants.
Any questions/remarks made within the /*commented out*/ portions of the code are directed 
towards them and should be ignored for any other reason.

This assignment was submitted on September 21st, 2016 and has not yet received a grade.

The assignment specification is included in the repository under 'a3spec.pdf'.

