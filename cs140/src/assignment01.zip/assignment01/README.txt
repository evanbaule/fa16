README

Evan M. Baule
Binghamton University - Watson Computer Science 2016

This code was submitted to be graded by the class instructor and/or teaching assistants.
Any questions/remarks made within the /*commented out*/ portions of the code are directed 
towards them and should be ignored for any other reason.

This assignment was submitted on September 7th, 2016 and received a score of 10/10.

The assignment specification is included in the repository under ‘a1spec.pdf’.





