package assignment01;

public class University{
	private String name;
	private String city;

	/*
	Constructor
	*/
	public University(String sName, String sCity){
		name = sName;
		city = sCity;
	}

	/*
	name getter/setter
	*/
	public String getName(){
		return name;
	}

	public void setName(String newName){
		name = newName;
	}

	/*
	city getter/setter
	*/
	public String getCity(){
		return city;
	}

	public void setCity(String newCity){
		city = newCity;
	}
}