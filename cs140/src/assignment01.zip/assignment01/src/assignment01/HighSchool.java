package assignment01;

public class HighSchool{
	private String name;

	/*
	Constructor
	*/
	public HighSchool(String sName){
		name = sName;
	}

	/*
	Name getter/setter
	*/
	public String getName(){
		return name;
	}

	public void setName(String newName){
		name = newName;
	}
}