package assignment01;

public class Employee{
	private Company company;
	private double salary;
	private Person person;

	/*
	Constructor
	*/
	public Employee(Company sCompany, double sSalary, Person sPerson){
		company = sCompany;
		salary = sSalary;
		person = sPerson;
		person.getHistory()[2] = this;
	}

	/*
	company getter/setter
	*/
	public Company getCompany(){
		return company;
	}

	public void setCompany(Company newCompany){
		company = newCompany;
	}

	/*
	salary getter/setter
	*/
	public double getSalary(){
		return salary;
	}

	public void setSalary(double newSalary){
		salary = newSalary;
	}

	/*
	person getter/setter
	*/
	public Person getPerson(){
		return person;
	}

	public void setPerson(Person newPerson){
		person = newPerson;
	}
}