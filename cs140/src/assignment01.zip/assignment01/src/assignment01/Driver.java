package assignment01;
/*
 * Evan M. Baule
 * Assignment 01
 * September 7th, 2016
 * CS 140
 */

public class Driver{
	public static void main(String[] args){

		//People
		Person personEvan = new Person("Evan", 11, 6, 1997);
		Person personSanad = new Person("Sanad", 22, 1, 1997);
		Person personMike = new Person("Mike", 02, 8, 1997);
		Person personBrandon = new Person("Brandon", 3, 3, 1997);

		Person[] students = {personEvan, personSanad, personMike, personBrandon};

		//High Schools
		HighSchool hsWG = new HighSchool("West Genesee");
		HighSchool hsBV = new HighSchool("Baldwinsville");
		HighSchool hsCNS = new HighSchool("Cicero North Syracuse");

		//Universities
		University uniBing = new University("Binghamton University", "Vestal");
		University uniRIT = new University("Rochester Institute of Technology", "Rochester");

		//Companies
		Company compMicrosoft = new Company("Microsoft", "Seattle");

		//Send to HS
		HighSchoolStudent hsEvan = new HighSchoolStudent(hsWG, personEvan);
		HighSchoolStudent hsMike = new HighSchoolStudent(hsBV, personMike);
		HighSchoolStudent hsSanad = new HighSchoolStudent(hsCNS, personSanad);

		//Send to University
		UniversityStudent uniEvan = hsEvan.goToUniversity(uniBing, personEvan);
		UniversityStudent uniSanad = hsSanad.goToUniversity(uniRIT, personSanad);

		//Get a job
		uniEvan.getAJob(compMicrosoft, 140000.00, personEvan);

		for(int i = 0; i < students.length-1; i++){
			students[i].printHistory();
			System.out.println("--------------------------------------------------------------------");
		}


	}
}