package assignment01;

public class UniversityStudent{
	private University university;
	private Person person;

	/*
	Constructor
	*/
	public UniversityStudent(University sUniversity, Person sPerson){
		university = sUniversity;
		person = sPerson;
		person.getHistory()[1] = this;
	}

	/*
	university getter/setter
	*/
	public University getUniversity(){
		return university;
	}

	public void setUniversity(University newUni){
		university = newUni;
	}

	/*
	person getter/setter
	*/
	public Person getPerson(){
		return person;
	}

	public void setPerson(Person newPerson){
		person = newPerson;
	}

	/*
	Get a job for the graduate
	*/
	public Employee getAJob(Company comp, double startingSalary, Person person){
		Employee newEmployee = new Employee(comp, startingSalary, person);
		return newEmployee;
	}
}