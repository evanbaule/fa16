package assignment06;

public class UndergradCourse extends Course {

	public UndergradCourse(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public boolean isUnderGrad(){
		return true;
	}
	
	@Override
	public boolean  isGrad(){
		return false;
	}

}
