package assignment06;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Random;


public class Question2 {
	public static Course[] courseArray = new Course[600];
	public static Student[] studentArray = new Student[6000];
	static{
		
		Random rand = new Random();
		
		//Populate course array
		for(int i = 0; i < 399; i++){
			courseArray[i] = new UndergradCourse(Question1.name(rand.nextInt(308915776)));
		}
		for(int j = 400; j < courseArray.length; j++){
			courseArray[j] = new GraduateCourse(Question1.name(rand.nextInt(308915776)));
		}
		
		//Populate student array
		for(int k = 0; k < 4999; k++){
			studentArray[k] = new UndergradStudent(Question1.name(rand.nextInt(308915776)));
		}
		for(int m = 5000; m < studentArray.length; m++){
			studentArray[m] = new GraduateStudent(Question1.name(rand.nextInt(308915776)));
		}
		
		ArrayList<Course> list = new ArrayList<Course>(Arrays.asList(courseArray));
		Collections.shuffle(list);
		courseArray = list.toArray(courseArray);
		
		ArrayList<Student> list2 = new ArrayList<Student>(Arrays.asList(studentArray));
		Collections.shuffle(list2);
		studentArray = list2.toArray(studentArray);
		
		for(int i = 0; i < studentArray.length; i++){
			for(int j = 0; j < 4; j++){
				studentArray[i].addCourse(courseArray[rand.nextInt(600)]);
			}
		}
		
	}
	/*
	public int maxClass(Course c){
		int max = 0;
		for(int i = 0; i < c.getEnrollmentSize(); i++){
			if(c.tallyEnrollment(studentArray) > max){
				max = c.tallyEnrollment(studentArray);
			}
		}
		
		return max;
	}
	*/
	
	public int minClass(Course c){
		int min = 0;
		
		return min;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
