package assignment06;

public class UndergradStudent extends Student {

	public UndergradStudent(String major) {
		super(major);
	}
	@Override
	public void adjustSchedule(){
		int ctr = 0;
	}
	
	@Override
	public boolean isUnderGrad(){
		return true;
	}
	

}
