package assignment06;

public class GraduateStudent extends Student {
	private String undergradMajor;
	public GraduateStudent(String major) {
		super(major);
		undergradMajor = major;
	}
	@Override
	public void adjustSchedule(){
		/* This is retarded
		int ctr = 0;
		for(int i = 0; i < schedule.size(); i++){
			if(!(schedule.get(i).isGrad())){
				ctr++;
			}
		}
		*/
		
		
	}
	
	@Override
	public boolean isGrad(){
		return true;
	}

}