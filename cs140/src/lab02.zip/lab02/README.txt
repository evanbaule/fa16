README

Evan M. Baule
Binghamton University - Watson Computer Science 2016

This code was submitted to be graded by the class instructor and/or teaching assistants.
Any questions/remarks made within the /*commented out*/ portions of the code are directed 
towards them and should be ignored for any other reason.

This lab assignment was submitted on September 1st, 2016 and received a score of 7.5/10.

The assignment specification is included in the repository under 'lab02.pdf'

