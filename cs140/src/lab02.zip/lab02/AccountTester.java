package lab02;


/*

Evan M. Baule
Lab 02 - Thursday September 1st, 2016

*/

public class AccountTester{

	public static void main(String[] args){

		Account[] accountArray = new Account[10];
		
		int balanceVar = 1;//The sole purpose of this variable is to give each account a different starting balance, it will increment for each iteration of the for/each loop.
		

		/*for(Account a: accountArray){
			a = new Account(balanceVar);
			balanceVar++;	
		}*/

		for(int i = 0; i < 10; i++){
			accountArray[i] = new Account(balanceVar);
			balanceVar++;
		}

		System.out.println("The maximum value by for-each loop is: " + maxBalAccount(accountArray));
		System.out.println("The maximum value by for loop is: " + maxBalAccount2(accountArray));
		System.out.println("The minimum value by for-each loop is: " + minBalAccount(accountArray));
		System.out.println("The minimum value by for loop is: " + minBalAccount2(accountArray));
		for(Account a: accountArray){System.out.println("The value in the account is: " + a.money);}
		depositTo(accountArray, 25);
		for(Account a: accountArray){System.out.println("The value in the account is: " + a.money);}

		
	
	}

	public static int maxBalAccount(Account[] arr){
		
		Account maxAccount = arr[1];
		for(Account a: arr){
			if(a.money > maxAccount.money) maxAccount = a;
		} 
		return maxAccount.money;
		
	}
	public static int maxBalAccount2(Account[] arr){
		
		Account maxAccount = arr[1];
		
		for(int i = 0; i < arr.length; i++){
			if(arr[i].money > maxAccount.money) maxAccount = arr[i];

		}
		return maxAccount.money;

	}
	public static int minBalAccount(Account[] arr){
		
		Account minAccount = arr[1];
		for(Account a: arr){
			if(a.money < minAccount.money) minAccount = a;
		} 
		return minAccount.money;
		
	}
	public static int minBalAccount2(Account[] arr){
		
		Account minAccount = arr[1];
		
		for(int i = 0; i < arr.length-1; i++){
			if(arr[i].money < minAccount.money) minAccount = arr[i];

		}
		return minAccount.money;

	}
	public static Account[] depositTo(Account[] arr, int amt){
		System.out.println(amt + " was deposited to each account.");
		for(Account a: arr) {
			a.deposit(amt);
		}	
		return arr;	
	}
}
