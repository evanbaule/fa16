package assignment08;

import static org.junit.Assert.*;

import org.junit.Test;

public class LinkedListTest2 {

	private IntLinkedList2 lle = new IntLinkedList2();

	@Test
	public void emptyList() {
		IntLinkedList2 ll = new IntLinkedList2();
		assertEquals("[]", ll.toString());
	}

	@Test
	public void testAdd() {
		IntLinkedList2 ll = new IntLinkedList2();
		ll.startList(1);
		assertEquals("[1]", ll.toString());
	}

	@Test
	public void removeHead() {
		IntLinkedList2 ll = new IntLinkedList2();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(1);
		assertEquals("[3, 5]", ll.toString());
	}

	@Test
	public void removeMid() {
		IntLinkedList2 ll = new IntLinkedList2();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(3);
		assertEquals("[1, 5]", ll.toString());
	}

	@Test
	public void removeLast() {
		IntLinkedList2 ll = new IntLinkedList2();
		ll.startList(1);
		ll.appendList(3);
		ll.appendList(5);
		ll.remove(5);
		assertEquals("[1, 3]", ll.toString());
	}

}
